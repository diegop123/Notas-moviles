package com.example.practico1notas

import ColorPickerDialog
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.practico1notas.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var noteInput: EditText
    private lateinit var addNoteButton: Button
    private lateinit var notesRecyclerView: RecyclerView
    private val notes = mutableListOf<Note>()
    private lateinit var adapter: NoteAdapter

    private val availableColors = arrayOf(
        Color.parseColor("#FF8C00") to "Naranja",    // Dark Orange
        Color.parseColor("#FF69B4") to "Rosa",       // Hot Pink
        Color.parseColor("#4B0082") to "Morado",     // Indigo
        Color.parseColor("#00CED1") to "Turquesa",   // Dark Turquoise
        Color.parseColor("#FFD700") to "Dorado",     // Gold
        Color.parseColor("#ADFF2F") to "Verde Lima", // Green Yellow
        Color.parseColor("#FF4500") to "Rojo Anaranjado", // Orange Red
        Color.parseColor("#1E90FF") to "Azul Cielo", // Dodger Blue
        Color.parseColor("#DDA0DD") to "Ciruela",    // Plum
        Color.parseColor("#F08080") to "Salmón"      // Light Coral
    )



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inicialización de las vistas
        noteInput = binding.noteInput
        addNoteButton = binding.addNoteButton
        notesRecyclerView = binding.notesRecyclerView

        // Configura el RecyclerView y el adaptador
        setupRecyclerView()

        // Agregar evento al botón para añadir nota
        addNoteButton.setOnClickListener {
            addNote()
        }
    }

    // Configura el RecyclerView
    private fun setupRecyclerView() {
        notesRecyclerView.layoutManager = LinearLayoutManager(this)
        adapter = NoteAdapter(notes, ::editNote, ::deleteNote, ::changeNoteColor)
        notesRecyclerView.adapter = adapter
    }

    // Método para añadir una nueva nota
    private fun addNote() {
        val content = noteInput.text.toString().trim()
        if (content.isNotEmpty()) {
            notes.add(Note(content, Color.WHITE)) // Añade la nota con fondo blanco por defecto
            noteInput.text.clear() // Limpia el campo de texto
            adapter.notifyItemInserted(notes.size - 1) // Notifica al adaptador del nuevo elemento
            notesRecyclerView.scrollToPosition(notes.size - 1) // Desplaza al nuevo elemento
        } else {
            noteInput.error = "El contenido no puede estar vacío"
        }
    }

    // Método para editar una nota existente
    private fun editNote(position: Int) {
        val note = notes[position]
        val editText = EditText(this).apply {
            setText(note.content)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Editar Nota")
            .setView(editText)
            .setPositiveButton("OK") { _, _ ->
                val newContent = editText.text.toString().trim()
                if (newContent.isNotEmpty()) {
                    notes[position] = note.copy(content = newContent) // Actualiza la nota inmutablemente
                    adapter.notifyItemChanged(position) // Notifica el cambio al adaptador
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // Método para eliminar una nota
    private fun deleteNote(position: Int) {
        notes.removeAt(position) // Elimina la nota de la lista
        adapter.notifyItemRemoved(position) // Notifica al adaptador de la eliminación
    }

    private fun changeNoteColor(position: Int) {
        val colorPickerDialog = ColorPickerDialog(availableColors) { selectedColor ->
            notes[position].backgroundColor = selectedColor
            adapter.notifyItemChanged(position) // Notifica el cambio de color al adaptador
        }
        colorPickerDialog.show(supportFragmentManager, "colorPicker")
    }

}
