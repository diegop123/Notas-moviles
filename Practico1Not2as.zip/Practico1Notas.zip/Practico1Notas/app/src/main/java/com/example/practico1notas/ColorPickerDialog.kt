import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class ColorPickerDialog(
    private val colors: Array<Pair<Int, String>>,
    private val onColorSelected: (Int) -> Unit
) : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(requireContext())
        val colorNames = colors.map { it.second }.toTypedArray()

        builder.setTitle("Select Color")
            .setItems(colorNames) { _, which ->
                val selectedColor = colors[which].first
                onColorSelected(selectedColor)
            }
        return builder.create()
    }



    // Método que devuelve el nombre del color basado en el código de color
    private fun getColorName(color: Int): String {
        return when (color) {
            Color.GREEN -> "Verde"
            Color.YELLOW -> "Amarillo"
            Color.CYAN -> "Cian"
            Color.GRAY -> "Gris"
            Color.MAGENTA -> "Magenta" // Agregado
            Color.BLUE -> "Azul"
            Color.DKGRAY -> "Gris Oscuro"
            Color.RED -> "Rojo"
            Color.BLACK -> "Negro"
            Color.LTGRAY -> "Gris Claro" // Agregado
            Color.parseColor("#FF8C00") -> "Naranja"
            Color.parseColor("#FF69B4") -> "Rosa"
            Color.parseColor("#4B0082") -> "morado"
            Color.parseColor("#F08080") ->  "Salmón"
            else -> "Desconocido" // Si no se reconoce el color
        }
    }
}

