package com.example.practico1notas

data class Note(
    val content: String,
    var backgroundColor: Int
)
