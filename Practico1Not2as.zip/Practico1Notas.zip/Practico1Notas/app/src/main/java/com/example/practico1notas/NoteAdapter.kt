package com.example.practico1notas

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.practico1notas.databinding.ItemNoteBinding

class NoteAdapter(
    private val notes: MutableList<Note>,
    private val onEdit: (Int) -> Unit,
    private val onDelete: (Int) -> Unit,
    private val onColorChange: (Int) -> Unit
) : RecyclerView.Adapter<NoteAdapter.NoteViewHolder>() {

    inner class NoteViewHolder(val binding: ItemNoteBinding) : RecyclerView.ViewHolder(binding.root) {
        init {
            binding.apply {
                editButton.setOnClickListener { onEdit(adapterPosition) }
                deleteButton.setOnClickListener { onDelete(adapterPosition) }
                colorButton.setOnClickListener { onColorChange(adapterPosition) }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val binding = ItemNoteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NoteViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        val note = notes[position]
        holder.binding.apply {
            noteContent.text = note.content
            root.setBackgroundColor(note.backgroundColor)
        }
    }

    override fun getItemCount(): Int = notes.size

    // Helper function to update notes data
    fun updateNotes(newNotes: List<Note>) {
        notes.clear()
        notes.addAll(newNotes)
        notifyDataSetChanged()
    }
}
